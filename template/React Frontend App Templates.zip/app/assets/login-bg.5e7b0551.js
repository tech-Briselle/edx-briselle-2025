const g="/assets/login-bg.4b614fc6.png";export{g as b};
