const s="/assets/ils1.488442d7.svg";export{s as I};
