const s="/assets/post-1.4647ba55.png";export{s as p};
