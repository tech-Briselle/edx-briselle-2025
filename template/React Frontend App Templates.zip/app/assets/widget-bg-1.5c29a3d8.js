const s="/assets/widget-bg-1.e52f9df1.png";export{s as w};
