const s="/assets/user-big.b775f787.png";export{s as U};
