import{b as e}from"./setPrototypeOf.fcb4f614.js";function p(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,e(t,o)}export{p as _};
