const s="/assets/widget-bg-2.035e0098.png";export{s as w};
