import{G as r}from"./upperFirst.6911f9f8.js";var u=r;function i(a,s){return u(a,s)}var l=i;export{l as i};
