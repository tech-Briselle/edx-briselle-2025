// tailwind.config.cjs
const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
    content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', ...defaultTheme.fontFamily.sans],
            },
        },
    },
    safelist: [
        'hover:bg-gray-100',
        'hover:bg-gray-200',
        'hover:bg-red-100',
        'hover:bg-blue-100',
        'dark:hover:bg-gray-800',
        'dark:hover:bg-blue-800',
        'dark:hover:bg-red-800',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Outfit', ...defaultTheme.fontFamily.sans],
            },
        },
    },

    plugins: [],
};
