// ObjectsList.tsx
import { useState } from 'react';
import { BriselleTable } from './NewTbl2025';
import { Plus, Search, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ObjectType {
  id: string;
  name: string;
  apiName: string;
  description: string;
  recordCount: number;
  lastModified: string;
  isCustom: boolean;
}

export default function ObjectsList() {
  const [searchTerm, setSearchTerm] = useState('');

  const objects: ObjectType[] = [ /* same mock data */ ];

  const filtered = objects.filter((obj) =>
    [obj.name, obj.apiName, obj.description]
      .some(field => field.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const columns = [
    {
      key: 'name',
      label: 'Name',
      render: (row: ObjectType) => (
        <div className="flex items-center font-medium">
          {row.name}
          {row.isCustom && (
            <span className="ml-2 px-2 py-0.5 text-xs bg-accent text-white rounded-full">
              Custom
            </span>
          )}
        </div>
      ),
    },
    {
      key: 'apiName',
      label: 'API Name',
      render: (row: ObjectType) => (
        <code className="text-gray-500 text-xs">{row.apiName}</code>
      ),
    },
    { key: 'description', label: 'Description' },
    {
      key: 'recordCount',
      label: 'Records',
      render: (row: ObjectType) => row.recordCount.toLocaleString(),
    },
    { key: 'lastModified', label: 'Last Modified' },
    {
      key: 'actions',
      label: 'Actions',
      render: (row: ObjectType) => (
        <div className="flex space-x-2">
          <Link to={`/objects/${row.id}`} className="p-1 text-gray-500 hover:text-primary">
            <ExternalLink size={16} />
          </Link>
        </div>
      ),
    },
  ];

  return (
    <div className="fade-in">
      <div className="flex justify-between items-center mb-6">
        <h1 className="page-title mb-0">Objects</h1>
        <button className="btn btn-primary">
          <Plus size={16} className="mr-2" />
          New Object
        </button>
      </div>

      <div className="card mb-6">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <input
              type="text"
              placeholder="Search objects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 input"
            />
            <Search
              size={18}
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
            />
          </div>
        </div>

        <BriselleTable<ObjectType>
          data={filtered}
          columns={columns}
          rowKey="id"
        />
      </div>
    </div>
  );
}
