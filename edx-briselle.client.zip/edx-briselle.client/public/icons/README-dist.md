Salesforce Design System Icons

Contents:

action-sprite/   - sprited SVGs, see symbols.html and svg/symbols.svg
custom-sprite/
doctype-sprite/
standard-sprite/
utility-sprite/

action/          - individual 60x60 and 120x120 PNG icons, SVG icons
custom/
doctype/
standard/
utility/

License-for-icons.txt

